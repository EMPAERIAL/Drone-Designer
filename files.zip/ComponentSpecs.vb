' =============================================================================
' File:    Core/Models/ComponentSpecs.vb
' Purpose: Data model classes for UAV component specifications.
'          Contains a base ComponentSpec class and one subclass per component
'          category.  These are pure data-holders — no business logic lives here.
'          All selection / scoring logic belongs in Core/Services/.
'
' Usage across chats:
'   - ComponentSelectionEngine.vb reads and returns instances of these types.
'   - Module 2 (SolidWorks automation) consumes the mechanical properties
'     (Mass, Dimensions, MountingPattern, ShaftDiameter, etc.) to drive CAD.
'   - The JSON in Resources/components.json should map 1-to-1 to these classes;
'     ComponentRepository.vb is responsible for deserialisation.
'
' Naming convention:  every property uses PascalCase.
'                     Units are noted in the XML summary of each property.
' =============================================================================

Namespace Core.Models

    ' =========================================================================
    ' Enum: ComponentCategory
    ' =========================================================================

    ''' <summary>
    ''' Identifies the functional category of a UAV component.
    ''' Used for filtering, grouping, and driving subclass instantiation.
    ''' </summary>
    Public Enum ComponentCategory
        ''' <summary>Brushless or brushed drive motor.</summary>
        Motor

        ''' <summary>Electronic Speed Controller — drives a motor.</summary>
        ESC

        ''' <summary>Propeller blade assembly.</summary>
        Propeller

        ''' <summary>Autopilot / stabilisation flight controller board.</summary>
        FlightController

        ''' <summary>Rechargeable battery pack.</summary>
        Battery

        ''' <summary>GNSS positioning module.</summary>
        GPSModule

        ''' <summary>Air-to-ground data-link radio.</summary>
        TelemetryRadio

        ''' <summary>Optical, thermal, or multispectral imaging sensor.</summary>
        Camera

        ''' <summary>RC servo actuator (control surfaces, gimbal, etc.).</summary>
        Servo

        ''' <summary>RC link receiver.</summary>
        Receiver

        ''' <summary>Power Distribution Board — routes battery power to ESCs and BECs.</summary>
        PowerDistributionBoard
    End Enum

    ' =========================================================================
    ' Enum: MotorType
    ' =========================================================================

    ''' <summary>Electrical topology of a drive motor.</summary>
    Public Enum MotorType
        ''' <summary>Three-phase brushless outrunner or inrunner.</summary>
        Brushless
        ''' <summary>Traditional brushed DC motor.</summary>
        Brushed
    End Enum

    ' =========================================================================
    ' Enum: BatteryCellChemistry
    ' =========================================================================

    ''' <summary>Electrochemical cell type used in a battery pack.</summary>
    Public Enum BatteryCellChemistry
        ''' <summary>Lithium Polymer — most common for UAVs.</summary>
        LiPo
        ''' <summary>Lithium-Ion — higher energy density, lower C-rating.</summary>
        LiIon
        ''' <summary>Lithium Iron Phosphate — safer, heavier.</summary>
        LiFePO4
        ''' <summary>Nickel-Metal Hydride.</summary>
        NiMH
    End Enum

    ' =========================================================================
    ' Enum: GNSSConstellation
    ' =========================================================================

    ''' <summary>
    ''' Bit-flag enum of GNSS constellations a GPS module may support.
    ''' Combine with the Or operator: GPS Or GLONASS.
    ''' </summary>
    <Flags>
    Public Enum GNSSConstellation
        None = 0
        GPS = 1
        GLONASS = 2
        BeiDou = 4
        Galileo = 8
        QZSS = 16
        SBAS = 32
    End Enum

    ' =========================================================================
    ' Enum: ServoSignalType
    ' =========================================================================

    ''' <summary>Control signal protocol accepted by a servo or ESC.</summary>
    Public Enum ServoSignalType
        ''' <summary>Standard 50 Hz PWM (1000–2000 µs pulse).</summary>
        AnalogPWM
        ''' <summary>Digital PWM — faster refresh, same pulse range.</summary>
        DigitalPWM
        ''' <summary>Serial bus protocol (e.g. Futaba S.Bus).</summary>
        SBus
        ''' <summary>Digital Serial (e.g. Hitec HSB).</summary>
        HiTecSerial
    End Enum

    ' =========================================================================
    ' Enum: RCLinkProtocol
    ' =========================================================================

    ''' <summary>Manufacturer / protocol family for an RC receiver or transmitter.</summary>
    Public Enum RCLinkProtocol
        FrSky_ACCST
        FrSky_ACCESS
        Futaba_FASST
        Futaba_FASSTest
        Spektrum_DSM2
        Spektrum_DSMX
        TBS_Crossfire
        ExpressLRS
        FlySky_AFHDS
        FlySky_AFHDS2A
        Other
    End Enum

    ' =========================================================================
    ' Enum: FlightControllerFirmware
    ' =========================================================================

    ''' <summary>Open- or closed-source firmware ecosystem a flight controller supports.</summary>
    Public Enum FlightControllerFirmware
        ArduPilot
        PX4
        Betaflight
        INAV
        Cleanflight
        Proprietary
        Multiple
    End Enum

    ' =========================================================================
    ' Enum: ESCProtocol
    ' =========================================================================

    ''' <summary>Digital or analogue signalling protocols supported by an ESC.</summary>
    <Flags>
    Public Enum ESCProtocol
        None = 0
        PWM = 1
        OneShot125 = 2
        OneShot42 = 4
        MultiShot = 8
        DShot150 = 16
        DShot300 = 32
        DShot600 = 64
        DShot1200 = 128
        ProShot = 256
    End Enum

    ' =========================================================================
    ' Enum: CameraOutputInterface
    ' =========================================================================

    ''' <summary>Video or data output interface of a camera / imaging sensor.</summary>
    Public Enum CameraOutputInterface
        AnalogNTSC_PAL
        HDMI
        MicroHDMI
        USB
        MIPI_CSI
        Ethernet
        SDI
        Other
    End Enum

    ' =========================================================================
    ' Enum: PowerConnectorType
    ' =========================================================================

    ''' <summary>Main battery / power connector type.</summary>
    Public Enum PowerConnectorType
        XT30
        XT60
        XT90
        EC3
        EC5
        Deans_T
        JST_PH
        JST_XH
        Anderson_Powerpole
        Bare_Wire
        Other
    End Enum

    ' =========================================================================
    ' Class: Dimensions3D
    ' =========================================================================

    ''' <summary>
    ''' Axis-aligned bounding box dimensions for a physical component.
    ''' All values in millimetres (mm).
    ''' </summary>
    Public Class Dimensions3D

        ''' <summary>Overall length along the X-axis in mm.</summary>
        Public Property Length As Double

        ''' <summary>Overall width along the Y-axis in mm.</summary>
        Public Property Width As Double

        ''' <summary>Overall height / depth along the Z-axis in mm.</summary>
        Public Property Height As Double

        ''' <summary>Creates a zero-size instance.</summary>
        Public Sub New()
        End Sub

        ''' <summary>Creates an instance with specified dimensions.</summary>
        ''' <param name="length">Length in mm.</param>
        ''' <param name="width">Width in mm.</param>
        ''' <param name="height">Height in mm.</param>
        Public Sub New(length As Double, width As Double, height As Double)
            Me.Length = length
            Me.Width = width
            Me.Height = height
        End Sub

        ''' <summary>Returns a human-readable string: "LxWxH mm".</summary>
        Public Overrides Function ToString() As String
            Return $"{Length}×{Width}×{Height} mm"
        End Function

    End Class

    ' =========================================================================
    ' Class: ComponentSpec  (base class)
    ' =========================================================================

    ''' <summary>
    ''' Abstract base class for all UAV component specifications.
    ''' Contains identity, physical, and environmental properties common to
    ''' every component category.  Concrete subclasses add category-specific
    ''' properties.
    ''' </summary>
    Public MustInherit Class ComponentSpec

        ' --- Identity --------------------------------------------------------

        ''' <summary>
        ''' Unique identifier for this component record.
        ''' Populated by ComponentRepository when loading from components.json.
        ''' </summary>
        Public Property Id As String = Guid.NewGuid().ToString()

        ''' <summary>
        ''' Human-readable product name (e.g. "T-Motor F60 Pro IV 1750KV").
        ''' </summary>
        Public Property Name As String = String.Empty

        ''' <summary>
        ''' Brand or manufacturer name (e.g. "T-Motor", "Holybro").
        ''' </summary>
        Public Property Manufacturer As String = String.Empty

        ''' <summary>
        ''' Manufacturer part number or SKU.  Useful for sourcing and BOM export.
        ''' </summary>
        Public Property PartNumber As String = String.Empty

        ''' <summary>
        ''' The functional category this component belongs to.
        ''' Determines which subclass should be used at runtime.
        ''' </summary>
        Public Property Category As ComponentCategory

        ' --- Physical --------------------------------------------------------

        ''' <summary>
        ''' Component mass in grams (g), excluding cables unless stated.
        ''' Critical for weight-budget calculations in the selection engine.
        ''' </summary>
        Public Property MassGrams As Double

        ''' <summary>
        ''' Outer envelope dimensions of the component (mm).
        ''' Used by Module 2 to size mounting features and clearance volumes.
        ''' </summary>
        Public Property Dimensions As New Dimensions3D()

        ' --- Electrical (common subset) --------------------------------------

        ''' <summary>
        ''' Minimum operating supply voltage in Volts (V).
        ''' </summary>
        Public Property MinVoltage As Double

        ''' <summary>
        ''' Maximum operating supply voltage in Volts (V).
        ''' </summary>
        Public Property MaxVoltage As Double

        ' --- Environmental ---------------------------------------------------

        ''' <summary>
        ''' Minimum operating ambient temperature in degrees Celsius (°C).
        ''' </summary>
        Public Property MinOperatingTempC As Double = -20.0

        ''' <summary>
        ''' Maximum operating ambient temperature in degrees Celsius (°C).
        ''' </summary>
        Public Property MaxOperatingTempC As Double = 60.0

        ' --- Sourcing / meta -------------------------------------------------

        ''' <summary>
        ''' Approximate retail price in USD at time of data entry.
        ''' Not used in selection scoring; informational only.
        ''' </summary>
        Public Property PriceUSD As Double

        ''' <summary>
        ''' Freeform notes — data-quality warnings, compatibility caveats, etc.
        ''' </summary>
        Public Property Notes As String = String.Empty

        ' --- Convenience -----------------------------------------------------

        ''' <summary>
        ''' Returns a short display string: "Category | Manufacturer Name".
        ''' </summary>
        Public Overrides Function ToString() As String
            Return $"{Category} | {Manufacturer} {Name}"
        End Function

    End Class

    ' =========================================================================
    ' Class: MotorSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for a brushless or brushed drive motor.
    ''' KV, thrust, power, and mounting data are the primary inputs to the
    ''' propulsion sizing algorithm in ComponentSelectionEngine.
    ''' </summary>
    Public Class MotorSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Velocity constant in RPM per Volt (KV).
        ''' Higher KV = faster spinning at lower torque; lower KV for large props.
        ''' </summary>
        Public Property KV As Integer

        ''' <summary>
        ''' Maximum continuous shaft power output in Watts (W).
        ''' </summary>
        Public Property MaxPowerWatts As Double

        ''' <summary>
        ''' Maximum continuous current draw in Amperes (A) at rated voltage.
        ''' </summary>
        Public Property MaxCurrentAmps As Double

        ''' <summary>
        ''' No-load current draw at 10 V in Amperes (A).
        ''' Used for efficiency estimation at partial throttle.
        ''' </summary>
        Public Property NoLoadCurrentAmps As Double

        ''' <summary>
        ''' Internal resistance of the motor windings in milliohms (mΩ).
        ''' Affects heat generation and efficiency calculations.
        ''' </summary>
        Public Property InternalResistanceMilliOhm As Double

        ''' <summary>
        ''' Maximum static thrust produced with the recommended propeller in grams (g).
        ''' Used for thrust-to-weight ratio checks.
        ''' </summary>
        Public Property MaxThrustGrams As Double

        ''' <summary>
        ''' Propeller size (diameter × pitch, e.g. "10×4.5") at which MaxThrustGrams
        ''' was measured.  String format: "DiameterxPitch" in inches.
        ''' </summary>
        Public Property MaxThrustTestPropeller As String = String.Empty

        ''' <summary>
        ''' Motor shaft diameter in mm.  Required by Module 2 for prop-adapter CAD.
        ''' </summary>
        Public Property ShaftDiameterMm As Double

        ''' <summary>
        ''' Stator diameter (the wound core) in mm.  Part of the "XXXX" designation,
        ''' e.g. 2306 = 23 mm stator diameter.
        ''' </summary>
        Public Property StatorDiameterMm As Double

        ''' <summary>
        ''' Stator height (winding stack height) in mm.  Second half of "XXXX"
        ''' designation, e.g. 2306 = 6 mm stator height.
        ''' </summary>
        Public Property StatorHeightMm As Double

        ''' <summary>
        ''' Number of magnetic poles on the rotor bell.
        ''' </summary>
        Public Property PoleCount As Integer

        ''' <summary>
        ''' Bolt-circle diameter for the motor-to-mount bolt pattern in mm.
        ''' Used by Module 2 to generate correct motor mount geometry.
        ''' </summary>
        Public Property MountingBoltCircleMm As Double

        ''' <summary>
        ''' Number of mounting bolts (typically 3 or 4).
        ''' </summary>
        Public Property MountingBoltCount As Integer = 4

        ''' <summary>
        ''' Motor topology — brushless is the norm for UAVs.
        ''' </summary>
        Public Property MotorType As MotorType = MotorType.Brushless

        ''' <summary>
        ''' Recommended minimum cell count (e.g. 4 for "4S min").
        ''' </summary>
        Public Property RecommendedMinCells As Integer

        ''' <summary>
        ''' Recommended maximum cell count (e.g. 6 for "6S max").
        ''' </summary>
        Public Property RecommendedMaxCells As Integer

        Public Sub New()
            Category = ComponentCategory.Motor
        End Sub

    End Class

    ' =========================================================================
    ' Class: ESCSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for an Electronic Speed Controller.
    ''' One ESC drives one motor.  The selection engine ensures each ESC's
    ''' current rating ≥ the paired motor's MaxCurrentAmps with headroom.
    ''' </summary>
    Public Class ESCSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Continuous current rating in Amperes (A).
        ''' Must exceed motor's MaxCurrentAmps (typically 20 % headroom minimum).
        ''' </summary>
        Public Property ContinuousCurrentAmps As Double

        ''' <summary>
        ''' Burst current rating in Amperes (A), sustainable for ~10 seconds.
        ''' </summary>
        Public Property BurstCurrentAmps As Double

        ''' <summary>
        ''' Minimum input voltage in Volts (V) — determines minimum battery cell count.
        ''' </summary>
        Public Property MinInputVoltage As Double

        ''' <summary>
        ''' Maximum input voltage in Volts (V) — determines maximum battery cell count.
        ''' </summary>
        Public Property MaxInputVoltage As Double

        ''' <summary>
        ''' Minimum Li-Po cell count supported (informational shorthand).
        ''' </summary>
        Public Property MinCellCount As Integer

        ''' <summary>
        ''' Maximum Li-Po cell count supported (informational shorthand).
        ''' </summary>
        Public Property MaxCellCount As Integer

        ''' <summary>
        ''' True if this ESC includes an onboard Battery Eliminator Circuit (BEC)
        ''' that outputs regulated 5 V or adjustable voltage for servos/FC.
        ''' </summary>
        Public Property HasBEC As Boolean

        ''' <summary>
        ''' BEC output voltage in Volts (V).  Zero / ignored when HasBEC = False.
        ''' </summary>
        Public Property BECVoltage As Double

        ''' <summary>
        ''' Maximum BEC output current in Amperes (A).  Zero when HasBEC = False.
        ''' </summary>
        Public Property BECCurrentAmps As Double

        ''' <summary>
        ''' Bitfield of digital/analogue signalling protocols this ESC accepts
        ''' from the flight controller.
        ''' </summary>
        Public Property SupportedProtocols As ESCProtocol = ESCProtocol.PWM

        ''' <summary>
        ''' Firmware shipped from the factory (e.g. "BLHeli_32", "AM32", "KISS").
        ''' Determines whether the ESC is field-reprogrammable.
        ''' </summary>
        Public Property Firmware As String = String.Empty

        ''' <summary>
        ''' True if the ESC supports bidirectional DSHOT telemetry (RPM feedback
        ''' to the flight controller without a separate telemetry wire).
        ''' </summary>
        Public Property SupportsBidirectionalDShot As Boolean

        ''' <summary>
        ''' True if this is a 4-in-1 ESC board (all four ESCs on one PCB).
        ''' Affects mounting strategy in Module 2.
        ''' </summary>
        Public Property IsQuadESC As Boolean = False

        Public Sub New()
            Category = ComponentCategory.ESC
        End Sub

    End Class

    ' =========================================================================
    ' Class: PropellerSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for a propeller blade assembly.
    ''' Diameter and pitch are the primary aerodynamic sizing inputs.
    ''' </summary>
    Public Class PropellerSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Blade diameter in inches (industry convention for UAV props).
        ''' </summary>
        Public Property DiameterInches As Double

        ''' <summary>
        ''' Blade pitch in inches — distance the prop would advance in one revolution
        ''' through solid material.
        ''' </summary>
        Public Property PitchInches As Double

        ''' <summary>
        ''' Number of blades (typically 2, 3, or 4).
        ''' </summary>
        Public Property BladeCount As Integer = 2

        ''' <summary>
        ''' Bore (centre hole) diameter in mm that fits over the motor shaft.
        ''' Must match or be adapted to MotorSpec.ShaftDiameterMm.
        ''' </summary>
        Public Property BoreDiameterMm As Double

        ''' <summary>
        ''' Primary blade material (e.g. "Carbon Fibre", "Nylon Glass-Filled", "Polycarbonate").
        ''' </summary>
        Public Property Material As String = String.Empty

        ''' <summary>
        ''' True if the blades are foldable (common for fixed-wing and long-range craft).
        ''' </summary>
        Public Property IsFoldable As Boolean = False

        ''' <summary>
        ''' Maximum safe rotational speed in RPM as rated by the manufacturer.
        ''' </summary>
        Public Property MaxRPM As Integer

        ''' <summary>
        ''' Static thrust in grams (g) at the specified test RPM.
        ''' </summary>
        Public Property StaticThrustGrams As Double

        ''' <summary>
        ''' RPM at which StaticThrustGrams was measured.
        ''' </summary>
        Public Property StaticThrustTestRPM As Integer

        ''' <summary>
        ''' True if this is a clockwise (CW) rotation prop.
        ''' False for counter-clockwise (CCW).  Multirotor sets include both.
        ''' </summary>
        Public Property IsClockwiseRotation As Boolean = True

        Public Sub New()
            Category = ComponentCategory.Propeller
        End Sub

    End Class

    ' =========================================================================
    ' Class: FlightControllerSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for a UAV flight controller / autopilot board.
    ''' Interface counts (UART, PWM outputs) determine peripheral compatibility.
    ''' </summary>
    Public Class FlightControllerSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' CPU / SoC identifier (e.g. "STM32H743", "STM32F405", "Raspberry Pi CM4").
        ''' </summary>
        Public Property Processor As String = String.Empty

        ''' <summary>
        ''' Primary IMU / gyroscope chip (e.g. "ICM-42688-P", "BMI270").
        ''' </summary>
        Public Property GyroscopeChip As String = String.Empty

        ''' <summary>
        ''' Primary accelerometer chip.  Often the same IC as the gyroscope.
        ''' </summary>
        Public Property AccelerometerChip As String = String.Empty

        ''' <summary>
        ''' True if an onboard barometer (altimeter) is present.
        ''' </summary>
        Public Property HasBarometer As Boolean = True

        ''' <summary>
        ''' Barometer chip identifier (e.g. "MS5611", "BMP388").  Empty if absent.
        ''' </summary>
        Public Property BarometerChip As String = String.Empty

        ''' <summary>
        ''' True if an onboard magnetometer (compass) is present.
        ''' </summary>
        Public Property HasMagnetometer As Boolean

        ''' <summary>
        ''' Number of full hardware UART serial ports (used for GPS, telemetry, RC, etc.).
        ''' </summary>
        Public Property UARTCount As Integer

        ''' <summary>
        ''' Number of hardware I²C buses available.
        ''' </summary>
        Public Property I2CBusCount As Integer

        ''' <summary>
        ''' Number of hardware SPI buses available.
        ''' </summary>
        Public Property SPIBusCount As Integer

        ''' <summary>
        ''' Number of PWM or DSHOT motor/servo output channels.
        ''' </summary>
        Public Property PWMOutputCount As Integer

        ''' <summary>
        ''' Number of analogue-to-digital converter (ADC) input channels
        ''' available for voltage/current sensing.
        ''' </summary>
        Public Property AnalogInputCount As Integer

        ''' <summary>
        ''' True if a microSD card slot is present for blackbox logging.
        ''' </summary>
        Public Property HasSDCardSlot As Boolean = True

        ''' <summary>
        ''' True if a USB port is present for configuration / firmware flashing.
        ''' </summary>
        Public Property HasUSB As Boolean = True

        ''' <summary>
        ''' True if the board includes a built-in onboard OSD (On-Screen Display) chip.
        ''' </summary>
        Public Property HasOSD As Boolean

        ''' <summary>
        ''' True if a built-in video transmitter (VTx) is present on the board.
        ''' </summary>
        Public Property HasBuiltInVTx As Boolean

        ''' <summary>
        ''' Firmware ecosystem(s) the flight controller officially supports.
        ''' </summary>
        Public Property SupportedFirmware As FlightControllerFirmware

        ''' <summary>
        ''' Mounting hole pattern — bolt circle diameter in mm, or standard size
        ''' string like "30.5×30.5", "M3 20×20", etc.
        ''' Used by Module 2 to position standoffs in the airframe.
        ''' </summary>
        Public Property MountingPatternMm As String = String.Empty

        ''' <summary>
        ''' Input supply voltage range minimum in Volts (V).
        ''' Some FCs accept 3.3 V from a BEC; others take direct 5 V.
        ''' </summary>
        Public Property InputVoltageMin As Double = 4.5

        ''' <summary>
        ''' Input supply voltage range maximum in Volts (V).
        ''' </summary>
        Public Property InputVoltageMax As Double = 5.5

        Public Sub New()
            Category = ComponentCategory.FlightController
        End Sub

    End Class

    ' =========================================================================
    ' Class: BatterySpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for a rechargeable battery pack.
    ''' The capacity (mAh), cell count (S), and C-rating are the three values
    ''' most critical to flight-time estimation.
    ''' </summary>
    Public Class BatterySpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Energy capacity in milliamp-hours (mAh).
        ''' </summary>
        Public Property CapacityMAh As Integer

        ''' <summary>
        ''' Number of cells wired in series.
        ''' Common UAV values: 3S (11.1 V), 4S (14.8 V), 6S (22.2 V).
        ''' </summary>
        Public Property CellCount As Integer

        ''' <summary>
        ''' Nominal cell voltage in Volts (V).  For LiPo this is 3.7 V/cell.
        ''' Nominal pack voltage = CellCount × NominalCellVoltage.
        ''' </summary>
        Public Property NominalCellVoltageV As Double = 3.7

        ''' <summary>
        ''' Fully-charged cell voltage in Volts (V).  For LiPo this is 4.2 V/cell.
        ''' </summary>
        Public Property FullChargeVoltagePerCellV As Double = 4.2

        ''' <summary>
        ''' Safe minimum discharge cell voltage in Volts (V).  For LiPo ≈ 3.5 V/cell.
        ''' </summary>
        Public Property MinCellVoltageV As Double = 3.5

        ''' <summary>
        ''' Continuous discharge rate in multiples of capacity (C).
        ''' Maximum continuous current (A) = CapacityMAh / 1000 × ContinuousCRating.
        ''' </summary>
        Public Property ContinuousCRating As Double

        ''' <summary>
        ''' Peak burst discharge rate in C.  Usually quoted for ≤10 seconds.
        ''' </summary>
        Public Property BurstCRating As Double

        ''' <summary>
        ''' Cell electrochemistry type.
        ''' </summary>
        Public Property Chemistry As BatteryCellChemistry = BatteryCellChemistry.LiPo

        ''' <summary>
        ''' Physical form factor (e.g. "Hardcase", "Softcase", "Cylindrical 21700").
        ''' </summary>
        Public Property FormFactor As String = String.Empty

        ''' <summary>
        ''' Discharge connector type fitted to this pack.
        ''' </summary>
        Public Property DischargeConnector As PowerConnectorType = PowerConnectorType.XT60

        ''' <summary>
        ''' Balance connector standard (e.g. "JST-XH", "TP-XH").  Always present
        ''' on multi-cell LiPo packs.
        ''' </summary>
        Public Property BalanceConnector As String = "JST-XH"

        ''' <summary>
        ''' Calculated nominal pack voltage in Volts (V).
        ''' Read-only derived value: CellCount × NominalCellVoltageV.
        ''' </summary>
        Public ReadOnly Property NominalPackVoltageV As Double
            Get
                Return CellCount * NominalCellVoltageV
            End Get
        End Property

        ''' <summary>
        ''' Calculated maximum continuous current in Amperes (A).
        ''' Read-only derived value: (CapacityMAh / 1000) × ContinuousCRating.
        ''' </summary>
        Public ReadOnly Property MaxContinuousCurrentAmps As Double
            Get
                Return (CapacityMAh / 1000.0) * ContinuousCRating
            End Get
        End Property

        Public Sub New()
            Category = ComponentCategory.Battery
        End Sub

    End Class

    ' =========================================================================
    ' Class: GPSModuleSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for a GNSS positioning module.
    ''' Compass presence and update rate are important for autonomous flight.
    ''' </summary>
    Public Class GPSModuleSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Bitfield of GNSS constellations the module can receive simultaneously.
        ''' </summary>
        Public Property SupportedConstellations As GNSSConstellation =
            GNSSConstellation.GPS Or GNSSConstellation.GLONASS

        ''' <summary>
        ''' Maximum position update rate in Hz (e.g. 5, 10, 18).
        ''' </summary>
        Public Property MaxUpdateRateHz As Integer

        ''' <summary>
        ''' Typical horizontal CEP accuracy in metres (m) under open sky.
        ''' </summary>
        Public Property HorizontalAccuracyMeters As Double

        ''' <summary>
        ''' True if an onboard compass (magnetometer) is integrated.
        ''' Dual-compass setups (FC + external GPS compass) reduce magnetic interference.
        ''' </summary>
        Public Property HasCompass As Boolean = True

        ''' <summary>
        ''' Compass chip identifier (e.g. "IST8310", "HMC5883L", "QMC5883L").
        ''' Empty if HasCompass = False.
        ''' </summary>
        Public Property CompassChip As String = String.Empty

        ''' <summary>
        ''' Number of satellite channels the receiver can track in parallel.
        ''' </summary>
        Public Property TrackingChannels As Integer

        ''' <summary>
        ''' Primary communication interface to the flight controller.
        ''' Typical values: "UART", "I2C", "SPI", "USB".
        ''' </summary>
        Public Property [Interface] As String = "UART"

        ''' <summary>
        ''' Default UART baud rate (e.g. 38400, 115200).
        ''' </summary>
        Public Property DefaultBaudRate As Integer = 38400

        ''' <summary>
        ''' GNSS chipset inside the module (e.g. "u-blox M8N", "u-blox F9P",
        ''' "Unicore UM982").
        ''' </summary>
        Public Property GNSSChipset As String = String.Empty

        ''' <summary>
        ''' Diameter of the circular module PCB in mm.
        ''' Used by Module 2 for GPS mast / mount design.  Zero if not circular.
        ''' </summary>
        Public Property PCBDiameterMm As Double

        Public Sub New()
            Category = ComponentCategory.GPSModule
        End Sub

    End Class

    ' =========================================================================
    ' Class: TelemetryRadioSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for an air-to-ground data-link radio used to send
    ''' MAVLink or similar telemetry to a ground-control station.
    ''' Comes in matched air-unit / ground-unit pairs; this class represents
    ''' the air unit mounted on the UAV.
    ''' </summary>
    Public Class TelemetryRadioSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Radio carrier frequency in MHz (e.g. 433, 915, 2400, 5800).
        ''' </summary>
        Public Property FrequencyMHz As Double

        ''' <summary>
        ''' Transmitter output power in milliwatts (mW).
        ''' </summary>
        Public Property OutputPowerMW As Double

        ''' <summary>
        ''' Equivalent output power in dBm.  Read-only derived:
        ''' 10 × Log10(OutputPowerMW).
        ''' </summary>
        Public ReadOnly Property OutputPowerDBm As Double
            Get
                If OutputPowerMW <= 0 Then Return Double.NegativeInfinity
                Return 10.0 * Math.Log10(OutputPowerMW)
            End Get
        End Property

        ''' <summary>
        ''' Quoted maximum range in kilometres (km) under line-of-sight conditions.
        ''' </summary>
        Public Property MaxRangeKm As Double

        ''' <summary>
        ''' Air-link data rate in bits per second (bps).
        ''' </summary>
        Public Property AirDataRateBps As Integer

        ''' <summary>
        ''' Telemetry protocol natively supported (e.g. "MAVLink 1", "MAVLink 2",
        ''' "Proprietary", "Transparent Serial").
        ''' </summary>
        Public Property TelemetryProtocol As String = "MAVLink 2"

        ''' <summary>
        ''' Physical interface to the flight controller (typically "UART").
        ''' </summary>
        Public Property FCInterface As String = "UART"

        ''' <summary>
        ''' True if this radio supports frequency-hopping spread spectrum (FHSS).
        ''' </summary>
        Public Property SupportsFHSS As Boolean

        ''' <summary>
        ''' True if this module can also relay RC (pilot) commands to the FC,
        ''' eliminating the need for a separate receiver.
        ''' </summary>
        Public Property SupportsRCPassthrough As Boolean

        Public Sub New()
            Category = ComponentCategory.TelemetryRadio
        End Sub

    End Class

    ' =========================================================================
    ' Class: CameraSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for an imaging sensor mounted on the UAV —
    ''' optical (RGB), thermal infrared, multispectral, or depth.
    ''' </summary>
    Public Class CameraSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Sensor type description (e.g. "RGB", "Thermal LWIR", "Multispectral",
        ''' "Depth / ToF", "NIR").
        ''' </summary>
        Public Property SensorType As String = "RGB"

        ''' <summary>
        ''' Horizontal image resolution in pixels.
        ''' </summary>
        Public Property ResolutionHorizontalPx As Integer

        ''' <summary>
        ''' Vertical image resolution in pixels.
        ''' </summary>
        Public Property ResolutionVerticalPx As Integer

        ''' <summary>
        ''' Diagonal field of view in degrees (°).
        ''' </summary>
        Public Property DiagonalFOVDegrees As Double

        ''' <summary>
        ''' Horizontal field of view in degrees (°).  Zero if not specified.
        ''' </summary>
        Public Property HorizontalFOVDegrees As Double

        ''' <summary>
        ''' Maximum video frame rate at full resolution, in frames per second (fps).
        ''' Zero if camera is stills-only.
        ''' </summary>
        Public Property MaxFrameRateFPS As Integer

        ''' <summary>
        ''' Primary data output interface.
        ''' </summary>
        Public Property OutputInterface As CameraOutputInterface = CameraOutputInterface.USB

        ''' <summary>
        ''' Focal length in millimetres (mm).  Zero for fixed wide-angle lenses
        ''' where focal length is embedded in FOV.
        ''' </summary>
        Public Property FocalLengthMm As Double

        ''' <summary>
        ''' True if the camera has an onboard electronic or mechanical image stabiliser.
        ''' </summary>
        Public Property HasStabilisation As Boolean

        ''' <summary>
        ''' True if this camera is sold as part of or designed for a gimbal assembly.
        ''' </summary>
        Public Property IsGimbalMounted As Boolean

        ''' <summary>
        ''' Average power consumption during active recording in Watts (W).
        ''' </summary>
        Public Property PowerConsumptionWatts As Double

        ''' <summary>
        ''' Operating supply voltage in Volts (V) — may differ from main bus voltage.
        ''' </summary>
        Public Property OperatingVoltageV As Double

        Public Sub New()
            Category = ComponentCategory.Camera
        End Sub

    End Class

    ' =========================================================================
    ' Class: ServoSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for an RC servo actuator used to deflect control surfaces,
    ''' operate landing gear, or drive a gimbal axis.
    ''' </summary>
    Public Class ServoSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Stall torque at rated voltage in kilogram-centimetres (kg·cm).
        ''' </summary>
        Public Property StallTorqueKgCm As Double

        ''' <summary>
        ''' Stall torque at rated voltage in Newton-metres (N·m).
        ''' Read-only derived: StallTorqueKgCm × 0.0981.
        ''' </summary>
        Public ReadOnly Property StallTorqueNm As Double
            Get
                Return StallTorqueKgCm * 0.0981
            End Get
        End Property

        ''' <summary>
        ''' Transit speed over 60 degrees of travel at rated voltage,
        ''' in seconds per 60° (s/60°).  Lower = faster.
        ''' </summary>
        Public Property SpeedSecPer60Deg As Double

        ''' <summary>
        ''' Rated operating voltage in Volts (V).
        ''' Common values: 4.8, 6.0, 7.4.
        ''' </summary>
        Public Property RatedVoltageV As Double

        ''' <summary>
        ''' No-load current draw in mA at rated voltage.
        ''' </summary>
        Public Property NoLoadCurrentMA As Double

        ''' <summary>
        ''' Stall current draw in mA at rated voltage.
        ''' </summary>
        Public Property StallCurrentMA As Double

        ''' <summary>
        ''' Total mechanical travel in degrees (°).  Typical = 120–180 °.
        ''' </summary>
        Public Property TotalTravelDeg As Double = 180.0

        ''' <summary>
        ''' Control signal protocol this servo accepts.
        ''' </summary>
        Public Property SignalType As ServoSignalType = ServoSignalType.AnalogPWM

        ''' <summary>
        ''' Gear train material (e.g. "Metal", "Karbonite", "Nylon", "Titanium").
        ''' Affects durability and crash resistance.
        ''' </summary>
        Public Property GearMaterial As String = String.Empty

        ''' <summary>
        ''' True if the servo output shaft has ball bearings (vs. bushings).
        ''' </summary>
        Public Property HasBallBearings As Boolean

        ''' <summary>
        ''' Servo case body width in mm (the narrow dimension, used for slot design).
        ''' </summary>
        Public Property BodyWidthMm As Double

        ''' <summary>
        ''' Servo case body length in mm (the long dimension).
        ''' </summary>
        Public Property BodyLengthMm As Double

        ''' <summary>
        ''' Servo case body height in mm (depth from base to top of output shaft boss).
        ''' </summary>
        Public Property BodyHeightMm As Double

        ''' <summary>
        ''' Mounting lug centre-to-centre distance in mm along the long axis.
        ''' Used by Module 2 to create servo pocket / bracket geometry.
        ''' </summary>
        Public Property MountingLugSpacingMm As Double

        Public Sub New()
            Category = ComponentCategory.Servo
        End Sub

    End Class

    ' =========================================================================
    ' Class: ReceiverSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for an RC link receiver.
    ''' Handles the pilot-command radio link; separate from TelemetryRadio.
    ''' </summary>
    Public Class ReceiverSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' RC protocol / manufacturer ecosystem.
        ''' </summary>
        Public Property Protocol As RCLinkProtocol

        ''' <summary>
        ''' Carrier frequency in MHz (e.g. 2400, 900).
        ''' </summary>
        Public Property FrequencyMHz As Double

        ''' <summary>
        ''' Number of independent RC channels output.
        ''' </summary>
        Public Property ChannelCount As Integer

        ''' <summary>
        ''' Output signal format to the flight controller
        ''' (e.g. "SBUS", "CRSF", "SUMD", "PPM", "PWM").
        ''' </summary>
        Public Property OutputFormat As String = "SBUS"

        ''' <summary>
        ''' True if the receiver provides a downlink RSSI (signal strength) output
        ''' that can be fed to the FC.
        ''' </summary>
        Public Property HasRSSIOutput As Boolean = True

        ''' <summary>
        ''' True if the receiver supports bidirectional telemetry back to the transmitter
        ''' (e.g. battery voltage, GPS position).
        ''' </summary>
        Public Property HasTelemetry As Boolean

        ''' <summary>
        ''' Quoted maximum control range in kilometres (km) under open-sky conditions.
        ''' </summary>
        Public Property MaxRangeKm As Double

        ''' <summary>
        ''' Number of onboard antenna ports.
        ''' </summary>
        Public Property AntennaCount As Integer = 1

        ''' <summary>
        ''' Operating supply voltage in Volts (V).
        ''' </summary>
        Public Property OperatingVoltageV As Double = 5.0

        ''' <summary>
        ''' Current draw in mA at operating voltage.
        ''' </summary>
        Public Property CurrentDrawMA As Double

        Public Sub New()
            Category = ComponentCategory.Receiver
        End Sub

    End Class

    ' =========================================================================
    ' Class: PowerDistributionBoardSpec
    ' =========================================================================

    ''' <summary>
    ''' Specifications for a Power Distribution Board (PDB) or Power Module.
    ''' Routes main battery current to ESCs and provides regulated rails for
    ''' avionics (FC, GPS, camera, etc.).
    ''' </summary>
    Public Class PowerDistributionBoardSpec
        Inherits ComponentSpec

        ''' <summary>
        ''' Maximum continuous through-current in Amperes (A) across all ESC pads.
        ''' </summary>
        Public Property MaxContinuousCurrentAmps As Double

        ''' <summary>
        ''' Peak burst current in Amperes (A).
        ''' </summary>
        Public Property BurstCurrentAmps As Double

        ''' <summary>
        ''' Maximum input voltage in Volts (V) — determines maximum battery cell count.
        ''' </summary>
        Public Property MaxInputVoltageV As Double

        ''' <summary>
        ''' Number of ESC solder pad sets (one per motor arm).
        ''' Typical values: 4, 6, 8.
        ''' </summary>
        Public Property ESCPadCount As Integer

        ''' <summary>
        ''' True if the board includes an onboard current sensor (Hall effect or shunt).
        ''' Enables real-time current/consumption monitoring by the FC.
        ''' </summary>
        Public Property HasCurrentSensor As Boolean

        ''' <summary>
        ''' Current sensor full-scale range in Amperes (A).  Zero if absent.
        ''' </summary>
        Public Property CurrentSensorMaxAmps As Double

        ''' <summary>
        ''' True if the board has a regulated 5 V BEC output for avionics.
        ''' </summary>
        Public Property Has5VBEC As Boolean

        ''' <summary>
        ''' Maximum current of the 5 V BEC output in Amperes (A).  Zero if absent.
        ''' </summary>
        Public Property BEC5VMaxAmps As Double

        ''' <summary>
        ''' True if the board has a regulated 12 V output (e.g. for VTx, camera).
        ''' </summary>
        Public Property Has12VBEC As Boolean

        ''' <summary>
        ''' Maximum current of the 12 V output in Amperes (A).  Zero if absent.
        ''' </summary>
        Public Property BEC12VMaxAmps As Double

        ''' <summary>
        ''' Battery input connector type on the board.
        ''' </summary>
        Public Property InputConnector As PowerConnectorType = PowerConnectorType.XT60

        ''' <summary>
        ''' Mounting hole pattern as a string (e.g. "30.5×30.5 M3",
        ''' "20×20 M2", "45×45 M3").  Used by Module 2 for stack layout.
        ''' </summary>
        Public Property MountingPatternMm As String = String.Empty

        ''' <summary>
        ''' True if ESC pads are arranged for a bottom-mounted (integrated stack)
        ''' layout rather than through-hole arms.
        ''' </summary>
        Public Property IsStackDesign As Boolean = True

        Public Sub New()
            Category = ComponentCategory.PowerDistributionBoard
        End Sub

    End Class

End Namespace
